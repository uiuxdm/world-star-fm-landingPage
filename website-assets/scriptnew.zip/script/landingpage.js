 // Navbar scroll effects
 let lastScrollTop = 0;

 window.addEventListener('scroll', function() {
     const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
     const desktopNavbar = document.getElementById('desktopNavbar');
     const mobileNavbar = document.getElementById('mobileNavbar');
     const bottomButtons = document.getElementById('bottomButtons');

     // Desktop navbar scroll effect
     if (window.innerWidth > 1024) {
         if (scrollTop > 100) {
             desktopNavbar.classList.add('scrolled');
         } else {
             desktopNavbar.classList.remove('scrolled');
         }
     } else {
         // Mobile navbar scroll effect
         if (scrollTop > 50) {
             mobileNavbar.classList.add('scrolled');
         } else {
             mobileNavbar.classList.remove('scrolled');
         }

         // Show/hide bottom buttons based on scroll direction
         if (scrollTop > lastScrollTop && scrollTop > 200) {
             // Scrolling down
             bottomButtons.style.transform = 'translateY(0)';
             bottomButtons.style.opacity = '1';
         } else if (scrollTop < 100) {
             // Near top of page
             bottomButtons.style.transform = 'translateY(100%)';
             bottomButtons.style.opacity = '0';
         }
     }

     lastScrollTop = scrollTop;
 });

 // Handle window resize
 window.addEventListener('resize', function() {
     const bottomButtons = document.getElementById('bottomButtons');
     
     if (window.innerWidth > 1024) {
         bottomButtons.style.transform = 'translateY(100%)';
         bottomButtons.style.opacity = '0';
     }
 });

 // Smooth scrolling for anchor links
 document.querySelectorAll('a[href^="#"]').forEach(anchor => {
     anchor.addEventListener('click', function (e) {
         e.preventDefault();
         const target = document.querySelector(this.getAttribute('href'));
         if (target) {
             target.scrollIntoView({
                 behavior: 'smooth',
                 block: 'start'
             });
         }
     });
 });

 // Initialize bottom buttons state
 document.addEventListener('DOMContentLoaded', function() {
     const bottomButtons = document.getElementById('bottomButtons');
     bottomButtons.style.transform = 'translateY(100%)';
     bottomButtons.style.opacity = '0';
     bottomButtons.style.transition = 'all 0.3s ease';
 });



 
        // Initialize Swiper
        var swiper = new Swiper('.servicesSwiper', {
            slidesPerView: 1.2,
            spaceBetween: 20,
            loop: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },
            breakpoints: {
                576: {
                    slidesPerView: 1.5,
                    spaceBetween: 20,
                },
                768: {
                    slidesPerView: 2.2,
                    spaceBetween: 25,
                },
                992: {
                    slidesPerView: 3.3,
                    spaceBetween: 30,
                },
                1200: {
                    slidesPerView: 3.3,
                    spaceBetween: 30,
                }
            }
        });
        
        // Add smooth hover effects
        document.querySelectorAll('.service-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-8px) scale(1.02)';
            });
            
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0) scale(1)';
            });
        });
        
        // Button click effects
        document.querySelectorAll('.primary-button button mb-4').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Add ripple effect
                const ripple = document.createElement('span');
                const rect = this.getBoundingClientRect();
                const size = Math.max(rect.height, rect.width);
                const x = e.clientX - rect.left - size / 2;
                const y = e.clientY - rect.top - size / 2;
                
                ripple.style.width = ripple.style.height = size + 'px';
                ripple.style.left = x + 'px';
                ripple.style.top = y + 'px';
                ripple.classList.add('ripple');
                
                this.appendChild(ripple);
                
                // Remove ripple after animation
                setTimeout(() => {
                    ripple.remove();
                }, 600);
                
                // Simulate action
                console.log('Contact button clicked!');
            });
        });


 
        
        function openUniqueContactModal() {
            document.getElementById('uniqueContactModalOverlay').classList.remove('unique-contact-hidden');
         
        }

        function closeUniqueContactModal() {
            document.getElementById('uniqueContactModalOverlay').classList.add('unique-contact-hidden');
            document.body.style.overflow = 'auto';
        }


function send(event) {
    event.preventDefault();

    // Collect and trim field values
    const name = $('#txt-name').val().trim();
    const phone = $('#txt-phone').val().trim();
    const currentCompany = $('#txt-companyName').val().trim();
    const message = $('#txt-message').val().trim();
    const location = $('#txt-location').val().trim();

    // Basic validation
    if (!name || !location || !phone || !currentCompany) {
        showMessage("Please fill in all required fields.", 'error');
        return; // Stop function if validation fails
    }

    // Build your payload
    var data = {
        Name: name,
        CurrentCompany: currentCompany, 
        Location: location,
        Phone: phone,
        Message: message,
        MailSettingsID: 18,
        CompanyURL: 'worldstarfm.com',
        CompanyName: 'worldstarfmlandingppage',
        BgColor: '#001E61',
        MiddleName: ''
    };

    // Post data to the server
    Post("https://panelcontrol.progbiz.io/api/ContactUs/send-client-mail-custom", JSON.stringify(data), 'Success');
}

function sendSubmit(event) {
    event.preventDefault();

    // Collect and trim field values
    const name = $('#userName').val().trim();
    const phone = $('#userPhone').val().trim();
    const currentCompany = $('#companyName').val().trim();
    const message = $('#userMessage').val().trim();
    const location = $('#userLocation').val().trim();

    // Basic validation
    if (!name || !location || !phone || !currentCompany) {
        showMessage("Please fill in all required fields.", 'error');
        return; // Stop function if validation fails
    }

    // Build your payload
    var data = {
        Name: name,
        CurrentCompany: currentCompany, 
        Location: location,
        Phone: phone,
        Message: message,
        MailSettingsID: 18,
        CompanyURL: 'worldstarfm.com',
        CompanyName: 'worldstarfmlandingppage',
        BgColor: '#001E61',
        MiddleName: ''
    };

    // Post data to the server
    Post("https://panelcontrol.progbiz.io/api/ContactUs/send-client-mail-custom", JSON.stringify(data), 'Success');
}

function Post(url, data, successFun) {
    $.ajax({
        type: "POST",
        url: url,
        data: data,
        headers: {
            'Content-Type': 'application/json',
        },
        contentType: "application/json; charset=utf-8",
        success: function (result) {
            window[successFun](result); // Call success function
        },
        error: function (result) {
            showMessage("Error in submission. Please try again.", 'error');
        }
    });
}

function Success(result) {
    showMessage("Form submitted successfully.", 'success');
    closeUniqueContactModal();
    window.dataLayer = window.dataLayer || [];
        window.dataLayer.push({
            event: 'gadformsubmitting'
        });
    ClearFields();
    
}

function ClearFields() {
    $('#userName').val('');
    $('#userPhone').val('');
    $('#companyName').val('');
    $('#userMessage').val('');
    $('#userLocation').val('');
    $('#txt-name').val('');
    $('#txt-phone').val('');
    $('#txt-companyName').val('');
    $('#txt-message').val('');
    $('#txt-location').val('');
}

// Show message function
function showMessage(message, type = 'info') {
    $('.form-message').remove();
    
    const messageClass = type === 'success' ? 'alert-success' : 
                        type === 'error' ? 'alert-danger' : 'alert-info';
    
    const messageHtml = `
      <div class="form-message alert ${messageClass}" style="
        position: fixed;
        top: 10px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 9999;
        min-width: 90%;
        max-width: 400px;
        padding: 15px;
        border-radius: 5px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        font-size: 16px;
        text-align: center;
        background-color: ${type === 'success' ? '#d4edda' : '#f8d7da'};
        color: ${type === 'success' ? '#155724' : '#721c24'};
      ">
        ${message}
        <button type="button" class="close" style="
          position: absolute;
          top: 10px;
          right: 15px;
          border: none;
          background: none;
          font-size: 20px;
          cursor: pointer;
        " onclick="$(this).parent().remove()">×</button>
      </div>
    `;
    
    $('body').append(messageHtml);
    
    setTimeout(() => {
      $('.form-message').fadeOut(() => {
        $('.form-message').remove();
      });
    }, 10000);
}
